(* Wolfram Language Init File *)

Get[ "LieART`LieART`"]