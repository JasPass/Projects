(* Paclet Info File *)

(* created 2019/06/27*)

Paclet[
    Name -> "LieART",
    Version -> "2.0.2",
    MathematicaVersion -> "6+",
    Extensions -> 
        {
            {"Documentation", Language -> All, MainPage -> "Guides/LieART"}
        }
]


